[![Netlify Status](https://api.netlify.com/api/v1/badges/c310dd4f-867e-4522-8abc-603580f3f53d/deploy-status)](https://app.netlify.com/sites/mediadownloader/deploys)

# Media Dowloader

https://mediadownloader.netlify.app/

This is a React App that let you Download **Videos** and **Pictures** from over a 100 websites like Youtube, Soundcloud, Facebook, etc.

*Made with get-video Rapid API*
