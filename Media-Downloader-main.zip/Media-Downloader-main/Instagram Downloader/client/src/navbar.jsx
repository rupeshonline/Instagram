import React from 'react';
import { NavLink } from 'react-router-dom';


const NavBar = () => {
    return (
      <div>
 
        
        <NavLink to={"/fb"}>Facebook downloader</NavLink>
        
     
      
      </div>
    );
  };

  export default NavBar;