import React from "react";


function DownloadButtonInvalid() {
  return (
    <div style={{ margin: "20px" }}>
      <h1 style={{ color: "red" }}>Invalid url</h1>
      <br />
      <p>Please Paste Valid URL</p>
      
    </div>
  );
}

export default DownloadButtonInvalid;
