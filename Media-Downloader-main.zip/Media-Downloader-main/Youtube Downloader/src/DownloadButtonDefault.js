import React from "react";
import "./DownloadButtonDefault.css";


function DownloadButtonDefault() {
  return (
    <div className="default">
      <h1>Paste the video url above</h1>
   
      
    </div>
  );
}

export default DownloadButtonDefault;
