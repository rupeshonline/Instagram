import React from "react";

class AppMessage extends React.Component {
  render() {
    return (
      <div class="wrapper">
        <div class="background"></div>
        <div class="foreground"></div>
      </div>
    );
  }
}

export default AppMessage
