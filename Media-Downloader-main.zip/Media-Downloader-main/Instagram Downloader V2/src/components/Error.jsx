const Error = () => {
    return(
        <div className="error-page">
            <h1>Error 404</h1>
            <p>The requested location could not be found</p>
        </div>
    )
}

export default Error;