# Media Downloader

Download Videos, Reels, IGTV, Youtube Videos, Youtube to mp3, Soundcloud Song Downloader, Adult Site Media Downloader in different qualities made from Node.Js, React.Js, Express.Js and Free GetRapid API. 

Download Instagram, Facebook images and videos (no api required). It's async/await lib.

Download and Convert Youtube Videos from 144p to HD format and mp3 format. Its better way to download online media, fast and safe.

Download Adult Videos Safe and free from all popular adult sites with all different qualities available.

## 1. Igvio - Instagram Media Downloader V2


<img src="https://user-images.githubusercontent.com/85479838/148687189-4b3bc519-0e9f-4cc5-8259-60883786c892.png" width="400" height="200"> <img src="https://user-images.githubusercontent.com/85479838/148687194-4780e328-00a4-4dca-8d7b-56ead467fce4.png" width="400" height="200">
<img src="https://user-images.githubusercontent.com/85479838/148687201-38ec1763-e875-4d02-b39a-bf8edd7c1f2c.png" width="400" height="200"> <img src="https://user-images.githubusercontent.com/85479838/148687203-968bc436-ab99-45ab-9086-99b27a5cb450.png" width="400" height="200">
<img src="https://user-images.githubusercontent.com/85479838/148687204-abf433d0-064d-4491-a33d-4cd5196b8297.png" width="400" height="200"> <img src="https://user-images.githubusercontent.com/85479838/148687207-03e14f34-ca8a-435a-ba27-6c128251953b.png" width="400" height="200">

```diff
+ Note: Use your API key, not Mine.
```

Download Instagram Photos, Videos, IGTV, Post Free, Fast & Secure no need to signup Just by Giving the URL Link of the instagram post and it will scrap the post for you.

Download Users stories, We help you for Instagram story download online with our Insta story saver page. You just paste the Instagram Username which one you want to download inside the input box and hit the download button.

Scrap the Insta Feed and stalk your favroit profile without letting them known and download their recent post. It works as a Profile stalker to stalk anyones profile just by entering username.

Insta DP Viewer allows you to download Instagram dp directly in your phone gallery in HD fromat of any public or private profile just enter username and see the magic.

### Features

* Download any public post/IGTV/Phtot/Videos from instagram.
* Download any public reel using sharable link.
* User Firendly and responsive Interface.
* Unlimited access to Photos and videos of an IG user
* Download Stories of users
* Stalk instagram profile
* Get recent 24 post of user by username
* Download Insta DP in HD format
* Its works deployed also
* No signin/Signup or creditial required

### Demo: https://yasin-ai.github.io/igvio/

## 1. Instagram Media Downloader (old)

![1](https://user-images.githubusercontent.com/85479838/141991071-f33d3bf0-67da-4755-9cd0-0b02c4ca4f3e.gif)



```diff
- Note: This webapp will not work Deployed Download the Source code and Run on your Localhost it will work fine or download the source code and Run from termux in your phone it will run fine on phone's browser localstorage.
```
Instagram user's photos and videos downloader. Download all media files from any Link. Made from NodeJS as a Backend and ReactJs for front End without any Use of API's

### Features

* Get any public post from instagram.
* Get any public reel using sharable link.
* User Firendly Interface.
* Unlimited access to Photos and videos of an IG user

### Demo: https://instait.herokuapp.com/

## 2. Facebook Media Downloader

![2](https://user-images.githubusercontent.com/85479838/142007063-f3e56d6a-e181-487f-998d-dc4c7fc6b896.gif)


```diff
- Note: This webapp will not work Deployed Download the Source code and Run on your Localhost it will work fine or download the source code and Run from termux in your phone it will run fine on phone's browser localstorage.
```

Download all of the photos in any Facebook album that you have permission to view.Build using NodeJs and vanilla Javascript with very minimal Lines of code.

### Features

* Download any Public Video in one click
* User Friendly Interface
* Unlimated access to Public Videos

### Demo: https://fbit.herokuapp.com/

## 2.1: FBvio - Facebook Media Downloader (V2)
+

<img src="https://user-images.githubusercontent.com/85479838/152647083-5e393df2-26a8-4b4e-a486-2823aeb7e60b.png" width="400" height="200"> <img src="https://user-images.githubusercontent.com/85479838/152647084-6dbb5ea1-1dd8-4bc8-9cbd-9fa90de2eb5f.png" width="400" height="200">
<img src="https://user-images.githubusercontent.com/85479838/152647086-e790a429-1c94-4030-9dd5-054d7e086b01.png" width="400" height="200"> <img src="https://user-images.githubusercontent.com/85479838/152647089-fe55421d-c3ba-408e-a333-d70b1438ce7f.png" width="400" height="200">

```diff
+ Note: This webapp is Running Fine deployed.
```

Download all of the photos in any Facebook album that you have permission to view.Build using ReactJs and Rapid API with very minimal Lines of code. Only Working Facebook downloader in Github That works deployed.

### Features

* Download any Public Video in one click
* User Friendly Interface
* Unlimated access to Public Videos

### Demo: https://yasin-ai.github.io/fbvio/#/fbvio/download

## 3. Youtube Media Downloader/Converter (Version 2)

<img src="https://user-images.githubusercontent.com/85479838/152538719-c972cea1-bb73-4f01-8ca4-d924ffd501c1.png" width="400" height="200"> <img src="https://user-images.githubusercontent.com/85479838/152538729-3477a58d-5599-46b9-8dbe-ae23170aa1e6.png" width="400" height="200">
<img src="https://user-images.githubusercontent.com/85479838/152538737-5fa39693-3db0-407b-af73-6565bc5e1cbe.png" width="400" height="200"> <img src="https://user-images.githubusercontent.com/85479838/152538742-d017c96d-0c1d-4cb2-9f0a-d9ef5e9fb2dd.png" width="400" height="200">


```diff
+ Note: This webapp is Running Fine deployed.
```

Download Videos from Youtube in all the available different formats from 144p to 1080p. You can also convert the Video in different mp3 format Just py pasting the link in input box.

Its is made using ReactJs in Frontend and Free Vevio API.

### Features

* Download Youtube video in all quality
* Convert Video into Mp3 directly
* Unlimited API use
* Written in very easy and understandable code
* Dosen't require Backend. Done in Just frontend.

### Demo: https://ytvio.netlify.app/

## 4. Soundcloud Downloader


![www_screencapture_com_2021-11-17_10_33](https://user-images.githubusercontent.com/85479838/142138241-93f07785-0d56-4c26-b11d-ccad3a4efb54.gif)


```diff
+ Note: This webapp is Running Fine deployed.
```

SoundCloud Downloader is a webapp to online download SoundCloud tracks, songs, music in MP3 format. Use this SoundCloud downloader to download SoundCloud high quality mp3 tracks in 128kbps & 320kbps speed.

Made Using ReactJs for frontend and Free API from Rapid API.

### Features

* Download Songs in Different Quality
* Made Using Just Frontend not backend
* Unlimited access to free API
* Secure and Fast Download
* Written in very easy and understandable code

### Demo: https://scdit.herokuapp.com/

### 5. Dailymotion/Adult Site Downloader

Download DailyMotion Videos as well as adult videos from almost all popular adult sites for free and in all different quality available. Made Using ReactJs for frontend and Free API from Rapid API.

### Features

* Download DailyMotion videos in all quality 
* Download adult video from all popular sites
* Different quality to choose from
* User Friendly interface
* Made only using frontend no backend required

### Demo: https://downitt.herokuapp.com/
