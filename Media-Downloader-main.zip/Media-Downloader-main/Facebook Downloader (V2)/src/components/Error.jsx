const Error = () => {
    return(
        <div className="error-page">
            <h3>Click the tool that you want to use from the above and enter details in inpur box</h3>
            
        </div>
    )
}

export default Error;